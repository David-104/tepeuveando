// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

// declaration of functions defined in demo.cpp
void  sdlutils_basic_demo(void);
